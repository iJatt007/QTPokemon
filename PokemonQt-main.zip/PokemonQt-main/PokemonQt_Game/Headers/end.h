#ifndef END_H
#define END_H


class End
{
public:
    End();
    ~End();

    void displayEnd(bool b);
};

#endif // END_H
