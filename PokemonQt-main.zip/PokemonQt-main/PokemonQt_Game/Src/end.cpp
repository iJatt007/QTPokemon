#include "Headers/end.h"

End::End()
{

}

End::~End()
{

}

void End::displayEnd(bool win)
{
    if (win) {

    }
}
